package com.example.demo.REST;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Product;

import com.example.demo.entity.ProductRepository;

@RestController
public class Controller {
	
	@Autowired
	ProductRepository productRepository;
	
	@GetMapping("/Test")
	public ResponseEntity getById(@RequestParam ("id") String id) {
		Optional<Product> list= productRepository.findById(id);
		return new ResponseEntity(list, HttpStatus.OK);
	}
}
